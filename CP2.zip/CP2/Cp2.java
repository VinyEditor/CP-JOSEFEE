package CP2;
import java.util.Scanner;


public class Cp2 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		Class[] listaAlunos;
		int id, rm, idCurso;
		String nome, matriculado, nomeCurso;
		String cursoAluno = null;
		 
		
		
		listaAlunos = new Class[2];
		
		for (int i = 0; i < 2; i++) {
			System.out.printf("Digite o ID do Aluno");
			id = ler.nextInt();
			
			System.out.printf("Digite o RM do Aluno");
			rm = ler.nextInt();
			
			System.out.printf("Digite o nome do Aluno");
			nome = ler.next();
			
			Class aluno = new Class();
			
			System.out.printf("O aluno está matriculado em algum curso?");
			matriculado = ler.next();
			
						
			if(matriculado.equals("sim")) {
				
				System.out.printf("Digite o ID do curso");
				idCurso = ler.nextInt();	
				
				System.out.printf("Digite o nome do curso");
				nomeCurso = ler.next();
				
				cursoAluno = new Curso, nomeCurso;
			}
			
			aluno.setCurso(cursoAluno);
			
			listaAlunos[i] = aluno;
		}
		
		
		for (int j = 0; j < listaAlunos.length; j++) {
			Class aluno = listaAlunos[j];
			
			System.out.printf("ID aluno: %d, RM aluno: %d, Nome do aluno: %s \n", aluno.getId(), aluno.getRm(),aluno.getNome());

			Curso alunoCurso = aluno.getCurso();
		
			
			if(alunoCurso != null) {
				System.out.printf("ID do curso: %d, Nome do Curso: %s \n", alunoCurso.getId(), alunoCurso.getNome());	
			}
			
		}
	
	}
}

